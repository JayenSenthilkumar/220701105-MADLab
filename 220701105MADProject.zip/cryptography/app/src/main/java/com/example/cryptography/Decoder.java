package com.example.cryptography;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class Decoder extends AppCompatActivity {
    private EditText editText;
    private TextView textView;
    private Button decryptButton, copyButton;
    private ClipboardManager clipboardManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_decoder);

        // Link UI components with their respective IDs
        editText = findViewById(R.id.editText);
        textView = findViewById(R.id.decryptedTextView);
        decryptButton = findViewById(R.id.decryptButton);
        copyButton = findViewById(R.id.copyButton);

        // Initialize clipboard manager
        clipboardManager = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);

        decryptButton.setOnClickListener(v -> {
            // Get the string from the edit text
            String inputText = editText.getText().toString();
            // Call the decode function from the com.example.cryptography.Decode class
            String decodedText = Decode.decode(inputText);
            // Set the decoded text to the text view for display
            textView.setText(decodedText);
        });

        copyButton.setOnClickListener(v -> {
            // Get the text from the text view
            String data = textView.getText().toString().trim();

            // Check if the text view is not empty
            if (!data.isEmpty()) {
                // Copy the text to the clipboard
                ClipData copiedTextClip = ClipData.newPlainText("text", data);
                clipboardManager.setPrimaryClip(copiedTextClip);

                // Display a toast message that the text has been copied
                Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show();
            }
        });
    }
}