package com.example.cryptography;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private Button encodeButton;
    private Button decodeButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        encodeButton = findViewById(R.id.btVar1);
        decodeButton = findViewById(R.id.btVar2);

        encodeButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, Encoder.class);
            startActivity(intent);
        });

        decodeButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, Decoder.class);
            startActivity(intent);
        });
    }
}