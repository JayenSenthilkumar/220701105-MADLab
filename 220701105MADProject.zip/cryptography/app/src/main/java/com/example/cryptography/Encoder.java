package com.example.cryptography;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class Encoder extends AppCompatActivity {
    private EditText editText;
    private TextView textView;
    private Button encryptButton, copyButton;
    private ClipboardManager clipboardManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_encoder);

        // Link the UI components with their respective IDs
        editText = findViewById(R.id.editText);
        textView = findViewById(R.id.encryptedTextView);
        encryptButton = findViewById(R.id.encryptButton);
        copyButton = findViewById(R.id.copyButton);

        // Initialize clipboard manager
        clipboardManager = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);

        encryptButton.setOnClickListener(v -> {

            // Get user input
            String inputText = editText.getText().toString();

            // Call the encode function from the Encode class
            String encodedText = Encode.encode(inputText);

            // Display the encrypted text
            textView.setText(encodedText);
        });

        copyButton.setOnClickListener(v -> {

            // Get the text from the TextView
            String data = textView.getText().toString().trim();

            // Check if the TextView is not empty
            if (!data.isEmpty()) {

                // Copy the text to the clipboard
                ClipData copiedTextClip = ClipData.newPlainText("text", data);
                clipboardManager.setPrimaryClip(copiedTextClip);

                // Display a toast message that the text has been copied
                Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show();
            }
        });
    }
}